# Google Bookmark Auto Organizer AI

- Original name: Google 書籤自動分類 AI
- English filename name: google-bookmark-auto-organizer-ai
- Intake status: In progress (build started)

## Goal
- Build a Chrome extension that auto-organizes root-level/unfiled bookmarks into `Main Category + Sub Category`.
- User reviews AI suggestions first, then confirms before any bookmark move is finalized.

## Target Users
- Primary: personal heavy bookmark user.
- Scale target for V1: around 100 to 300 bookmarks.

## Core Features
- Scan unfiled/root-level bookmarks.
- Cloud AI classification with 2 providers:
  - OpenRouter API
  - Gemini direct API
- Classification output structure: `main`, `sub`, `confidence`, `reason`.
- Review mode options before apply:
  - Per-category confirm
  - Per-bookmark confirm
- Apply confirmed reorganization into bookmark folders.
- Undo last apply action.

## Platform Scope
- V1: Chrome Extension (Manifest V3)

## UI Theme and Visual Direction
- Clean utility style, information-first UI.
- Bilingual-friendly labels (Traditional Chinese default).

## Key User Flows
1. User configures provider and API key.
2. User scans root-level bookmarks.
3. User selects review mode.
4. User runs AI classification and previews proposed folders/items.
5. User confirms and applies.
6. User can undo the latest apply.

## Data and Authentication
- Data source: Chrome bookmarks API.
- No mandatory app account in V1.
- Secret storage: local extension storage (`chrome.storage.local`) for API key.

## Integrations
- `chrome.bookmarks` API
- OpenRouter Chat Completions API
- Gemini `generateContent` API

## Delivery Plan and MVP Scope
- Immediate action: implement working prototype now.
- MVP boundaries:
  - Root-level scan only
  - One-click AI suggest
  - Review + confirm
  - Apply + undo

## Success Metrics
- 90%+ of bookmarks receive usable category suggestions.
- User can finish one full review/apply cycle in under 5 minutes for 100 bookmarks.
- Undo restores previous structure correctly for latest apply.

## Open Questions
- Default category taxonomy (initial built-in list) to be finalized by real usage.
- Whether to add scheduled auto-run in V2.
