const DEFAULT_SETTINGS = {
  provider: "openrouter",
  apiKey: "",
  model: "google/gemini-2.0-flash-001",
  granularity: "broad",
  topFolderName: "AI Auto Sorted",
  fallbackFolderName: "AI Filtered",
  batchSize: 20,
  temperature: 0.1,
  taxonomy: [
    "Server/一般",
    "Knowledge/一般",
    "Learning/一般",
    "Tools/一般",
    "News/一般"
  ]
};

const SYSTEM_PROMPT = [
  "Classify bookmarks into main/sub categories.",
  "Output JSON only:",
  '{"items":[{"id":"string","main":"string","sub":"string","confidence":0.0,"reason":"string"}]}',
  "Keep labels short. Preserve id exactly."
].join("\n");

const state = {
  settings: { ...DEFAULT_SETTINGS },
  roots: [],
  rootFolders: [],
  selectedFolderIds: [],
  bookmarks: [],
  bookmarkById: new Map(),
  suggestions: [],
  suggestionById: new Map(),
  classifyingFolderTargets: [],
  canUndo: false
};

const el = {
  openOptionsBtn: document.getElementById("openOptionsBtn"),
  scanScope: document.getElementById("scanScope"),
  destinationRoot: document.getElementById("destinationRoot"),
  targetFolders: document.getElementById("targetFolders"),
  refreshFoldersBtn: document.getElementById("refreshFoldersBtn"),
  selectAllTargetsBtn: document.getElementById("selectAllTargetsBtn"),
  clearTargetsBtn: document.getElementById("clearTargetsBtn"),
  targetFolderInfo: document.getElementById("targetFolderInfo"),
  reviewMode: document.getElementById("reviewMode"),
  scanBtn: document.getElementById("scanBtn"),
  scanResult: document.getElementById("scanResult"),
  classifyBtn: document.getElementById("classifyBtn"),
  providerInfo: document.getElementById("providerInfo"),
  reviewContainer: document.getElementById("reviewContainer"),
  applyBtn: document.getElementById("applyBtn"),
  undoBtn: document.getElementById("undoBtn"),
  statusBox: document.getElementById("statusBox")
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bind();
  await loadSettings();
  await loadRoots();
  await loadFolderTargets();
  await loadUndoState();
  status("就緒");
}

function bind() {
  el.openOptionsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());
  el.scanBtn.addEventListener("click", scanUnfiled);
  el.classifyBtn.addEventListener("click", classifyNow);
  el.applyBtn.addEventListener("click", applyNow);
  el.undoBtn.addEventListener("click", undoNow);
  el.reviewMode.addEventListener("change", renderReview);
  el.reviewContainer.addEventListener("change", refreshApplyButton);
  el.reviewContainer.addEventListener("input", refreshApplyButton);
  el.destinationRoot.addEventListener("change", async () => {
    await loadFolderTargets();
    invalidateSuggestions();
    await saveUiState();
  });
  el.refreshFoldersBtn.addEventListener("click", async () => {
    await loadFolderTargets();
    await saveUiState();
    status("已重新讀取資料夾");
  });
  el.selectAllTargetsBtn.addEventListener("click", async () => {
    for (const option of el.targetFolders.options) {
      option.selected = true;
    }
    state.selectedFolderIds = selectedFolderIdsFromUi();
    updateFolderInfo();
    invalidateSuggestions();
    await saveUiState();
  });
  el.clearTargetsBtn.addEventListener("click", async () => {
    for (const option of el.targetFolders.options) {
      option.selected = false;
    }
    state.selectedFolderIds = [];
    updateFolderInfo();
    invalidateSuggestions();
    await saveUiState();
  });
  el.targetFolders.addEventListener("change", async () => {
    state.selectedFolderIds = selectedFolderIdsFromUi();
    updateFolderInfo();
    invalidateSuggestions();
    await saveUiState();
  });
}

async function loadSettings() {
  const data = await storageGet("settings");
  const incoming = data.settings || {};
  state.settings = {
    ...DEFAULT_SETTINGS,
    ...incoming,
    granularity: incoming.granularity === "detailed" ? "detailed" : "broad",
    taxonomy: Array.isArray(incoming.taxonomy) && incoming.taxonomy.length > 0 ? incoming.taxonomy : DEFAULT_SETTINGS.taxonomy
  };
  const granularityText = state.settings.granularity === "broad" ? "粗分類" : "細分類";
  el.providerInfo.textContent = `${state.settings.provider} | ${state.settings.model} | ${granularityText}`;
}

async function loadRoots() {
  const tree = await bookmarksGetTree();
  state.roots = (tree[0]?.children || []).filter((node) => !node.url);
  const ui = await uiStateGet();

  el.scanScope.innerHTML = "";
  el.scanScope.add(new Option("全部根目錄", "all"));
  for (const root of state.roots) {
    el.scanScope.add(new Option(root.title || `Root ${root.id}`, root.id));
  }

  el.destinationRoot.innerHTML = "";
  for (const root of state.roots) {
    el.destinationRoot.add(new Option(root.title || `Root ${root.id}`, root.id));
  }

  if (ui.destinationRootId && state.roots.some((r) => r.id === ui.destinationRootId)) {
    el.destinationRoot.value = ui.destinationRootId;
    return;
  }
  const defaultRoot = state.roots.find((r) => r.id === "2") || state.roots[0];
  if (defaultRoot) {
    el.destinationRoot.value = defaultRoot.id;
  }
}

async function loadFolderTargets() {
  const rootId = el.destinationRoot.value;
  const children = await bookmarksGetChildren(rootId);
  state.rootFolders = children
    .filter((item) => !item.url)
    .map((item) => ({ id: item.id, title: item.title || "(untitled)" }))
    .sort((a, b) => a.title.localeCompare(b.title));

  el.targetFolders.innerHTML = "";
  for (const folder of state.rootFolders) {
    el.targetFolders.add(new Option(folder.title, folder.id));
  }

  const ui = await uiStateGet();
  const canRestore = ui.destinationRootId === rootId && Array.isArray(ui.selectedTargetFolderIds);
  const selected = canRestore ? ui.selectedTargetFolderIds : [];
  const allowed = new Set(state.rootFolders.map((f) => f.id));
  state.selectedFolderIds = selected.filter((id) => allowed.has(id));
  for (const opt of el.targetFolders.options) {
    opt.selected = state.selectedFolderIds.includes(opt.value);
  }
  updateFolderInfo();
}

function updateFolderInfo() {
  if (state.selectedFolderIds.length === 0) {
    el.targetFolderInfo.textContent = "未選擇目標資料夾，可由 AI 自動建立分類。";
    return;
  }
  el.targetFolderInfo.textContent = `已選 ${state.selectedFolderIds.length} 個目標資料夾，未匹配會入 ${state.settings.fallbackFolderName}`;
}

function selectedFolderIdsFromUi() {
  return [...el.targetFolders.options].filter((o) => o.selected).map((o) => o.value);
}

function selectedFolderObjsFromUi() {
  const set = new Set(selectedFolderIdsFromUi());
  state.selectedFolderIds = [...set];
  return state.rootFolders.filter((f) => set.has(f.id));
}

function invalidateSuggestions() {
  state.suggestions = [];
  state.suggestionById = new Map();
  state.classifyingFolderTargets = [];
  el.reviewContainer.innerHTML = '<div class="review-empty">範圍已變更，請重新分類。</div>';
  el.applyBtn.disabled = true;
}

async function scanUnfiled() {
  try {
    busy(true);
    const ids = el.scanScope.value === "all" ? state.roots.map((r) => r.id) : [el.scanScope.value];
    const found = [];
    for (const rootId of ids) {
      const children = await bookmarksGetChildren(rootId);
      for (const child of children) {
        if (!child.url) continue;
        found.push({
          id: child.id,
          title: child.title || "(untitled)",
          url: child.url,
          parentId: child.parentId,
          index: child.index
        });
      }
    }
    state.bookmarks = found;
    state.bookmarkById = new Map(found.map((x) => [x.id, x]));
    invalidateSuggestions();
    el.scanResult.textContent = `找到 ${found.length} 筆`;
    el.reviewContainer.innerHTML = '<div class="review-empty">掃描完成，請按「開始 AI 分類」。</div>';
    status(`已掃描 ${found.length} 筆`);
  } catch (e) {
    status(`掃描失敗：${e.message}`);
  } finally {
    busy(false);
  }
}

async function classifyNow() {
  if (!state.bookmarks.length) {
    status("沒有可分類書籤，請先掃描。");
    return;
  }
  if (!state.settings.apiKey || !state.settings.model) {
    status("請先在設定頁填 API key 與模型。");
    return;
  }
  try {
    busy(true);
    const targets = selectedFolderObjsFromUi();
    state.classifyingFolderTargets = targets;
    const suggestions = await classifyAll(state.bookmarks, state.settings, targets);
    state.suggestions = suggestions;
    state.suggestionById = new Map(suggestions.map((s) => [s.id, s]));
    renderReview();
    status(`分類完成：${suggestions.length} 筆`);
  } catch (e) {
    status(`分類失敗：${e.message}`);
  } finally {
    busy(false);
  }
}

async function classifyAll(bookmarks, settings, targets) {
  const batchSize = Math.max(1, Math.min(50, Number(settings.batchSize) || 20));
  const out = [];
  for (let i = 0; i < bookmarks.length; i += batchSize) {
    const batch = bookmarks.slice(i, i + batchSize);
    const parsed = await classifyBatch(batch, settings, targets);
    const byId = new Map((parsed.items || []).map((x) => [String(x.id), x]));
    for (const bm of batch) {
      const raw = byId.get(String(bm.id));
      let item = normalizeItem(bm, raw, settings.granularity);
      if (targets.length) item = constrainToTargets(item, targets, settings.fallbackFolderName);
      out.push(item);
    }
    status(`進度 ${Math.min(i + batch.length, bookmarks.length)}/${bookmarks.length}`);
  }
  return out;
}

async function classifyBatch(batch, settings, targets) {
  const hint = settings.taxonomy.length ? settings.taxonomy.join(", ") : "No taxonomy hint";
  const targetLine = targets.length ? `Allowed folders: ${targets.map((t) => t.title).join(", ")}` : "No fixed folders";
  const granularity = settings.granularity === "broad" ? "Prefer broad categories." : "Detailed categories allowed.";
  const fallback = `If no fit, main=\"${settings.fallbackFolderName}\", sub=\"未匹配\".`;
  const prompt = [
    targetLine,
    `Taxonomy hint: ${hint}`,
    granularity,
    fallback,
    "Input JSON:",
    JSON.stringify(batch.map((x) => ({ id: x.id, title: x.title, url: x.url })))
  ].join("\n\n");

  const raw = settings.provider === "gemini"
    ? await askGemini(prompt, settings)
    : await askOpenRouter(prompt, settings);
  const parsed = parseModelJson(raw);
  return parsed && Array.isArray(parsed.items) ? parsed : { items: [] };
}

function normalizeItem(bookmark, raw, granularity) {
  let item;
  if (!raw || typeof raw !== "object") {
    item = fallbackByKeyword(bookmark);
  } else {
    const main = label(raw.main);
    const sub = label(raw.sub);
    item = (main && sub)
      ? {
          id: bookmark.id,
          main,
          sub,
          confidence: clamp01(Number(raw.confidence)),
          reason: typeof raw.reason === "string" ? raw.reason.slice(0, 120) : ""
        }
      : fallbackByKeyword(bookmark);
  }
  if (granularity === "broad" && !["Uncertain", "AI Filtered"].includes(item.main)) {
    item.sub = "一般";
  }
  return item;
}

function fallbackByKeyword(bookmark) {
  const text = `${bookmark.title} ${bookmark.url}`.toLowerCase();
  if (/(server|devops|docker|kubernetes|k8s|nginx|linux|aws|gcp|azure|terraform|ansible)/.test(text)) {
    return mk(bookmark.id, "Server", "一般", 0.4, "關鍵字判斷");
  }
  if (/(learn|learning|course|tutorial|lesson|study|education)/.test(text)) {
    return mk(bookmark.id, "Learning", "一般", 0.4, "關鍵字判斷");
  }
  if (/(wiki|wikipedia|docs|reference|concept|knowledge|theory)/.test(text)) {
    return mk(bookmark.id, "Knowledge", "一般", 0.4, "關鍵字判斷");
  }
  if (/(news|trend|blog|release|update)/.test(text)) {
    return mk(bookmark.id, "News", "一般", 0.35, "關鍵字判斷");
  }
  return mk(bookmark.id, "Uncertain", "Needs-Review", 0.3, "無法判斷");
}

function mk(id, main, sub, confidence, reason) {
  return { id, main, sub, confidence, reason };
}

function constrainToTargets(item, targets, fallbackName) {
  const matched = pickTarget(item.main, item.sub, targets);
  if (matched) {
    return {
      ...item,
      main: matched.title,
      sub: "已指定",
      resolvedFolderId: matched.id,
      resolvedFolderTitle: matched.title,
      isFallback: false
    };
  }
  return {
    ...item,
    main: fallbackName,
    sub: "未匹配",
    resolvedFolderId: null,
    resolvedFolderTitle: fallbackName,
    isFallback: true
  };
}

function pickTarget(main, sub, targets) {
  const q = norm(`${main} ${sub}`);
  const m = norm(main);
  const s = norm(sub);
  if (!q) return null;
  let best = null;
  let bestScore = 0;
  for (const t of targets) {
    const n = norm(t.title);
    if (!n) continue;
    let score = 0;
    if (n === m) score += 100;
    if (n === s) score += 80;
    if (n === q) score += 120;
    if (m && n.includes(m)) score += 50;
    if (s && n.includes(s)) score += 30;
    if (q.includes(n)) score += 20;
    for (const token of q.split(" ").filter(Boolean)) {
      if (n.split(" ").includes(token)) score += 10;
    }
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  }
  return bestScore > 0 ? best : null;
}

function renderReview() {
  if (!state.suggestions.length) {
    el.reviewContainer.innerHTML = '<div class="review-empty">目前沒有分類建議。</div>';
    el.applyBtn.disabled = true;
    return;
  }
  if (el.reviewMode.value === "category") {
    renderCategory();
  } else {
    renderBookmark();
  }
  refreshApplyButton();
}

function categoryKey(item) {
  return `${item.main}|||${item.sub}|||${item.resolvedFolderTitle || ""}`;
}

function renderCategory() {
  const map = new Map();
  for (const item of state.suggestions) {
    const key = categoryKey(item);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
  const rows = [];
  for (const [key, items] of map.entries()) {
    const f = items[0];
    const sample = items.slice(0, 3).map((x) => esc(state.bookmarkById.get(x.id)?.title || x.id)).join(" / ");
    const target = f.resolvedFolderTitle ? ` -> ${esc(f.resolvedFolderTitle)}` : "";
    rows.push(
      `<div class="category-row"><label><input type="checkbox" class="category-check" data-key="${esca(key)}" checked>` +
      `<strong>${esc(f.main)} / ${esc(f.sub)}</strong>${target} <span class="badge">${items.length}</span></label>` +
      `<div class="meta">例如：${sample}</div></div>`
    );
  }
  el.reviewContainer.innerHTML = `<div class="category-grid">${rows.join("")}</div>`;
}

function renderBookmark() {
  const folderMode = state.classifyingFolderTargets.length > 0;
  const rows = state.suggestions.map((item) => {
    const b = state.bookmarkById.get(item.id);
    const title = esc(b?.title || "(遺失)");
    const url = esc(b?.url || "");
    const c = Number.isFinite(item.confidence) ? item.confidence.toFixed(2) : "0.00";
    const target = item.resolvedFolderTitle ? `<div class="meta">目標資料夾：${esc(item.resolvedFolderTitle)}</div>` : "";
    const editor = folderMode ? "" : (
      `<div class="inline-fields">` +
      `<label class="field"><span>主類</span><input class="bookmark-main" type="text" value="${esca(item.main)}"></label>` +
      `<label class="field"><span>子類</span><input class="bookmark-sub" type="text" value="${esca(item.sub)}"></label>` +
      `</div>`
    );
    return (
      `<div class="review-item" data-id="${esca(item.id)}">` +
      `<div class="review-item-header"><label><input type="checkbox" class="bookmark-check" checked></label><div>` +
      `<div class="review-item-title">${title}</div><div class="review-item-url">${url}</div>` +
      `<div class="meta">${esc(item.main)} / ${esc(item.sub)} | ${c}</div>${target}<div class="meta">${esc(item.reason || "")}</div>` +
      `</div></div>${editor}</div>`
    );
  });
  el.reviewContainer.innerHTML = `<div class="review-list">${rows.join("")}</div>`;
}

function confirmedFromUi() {
  if (!state.suggestions.length) return [];
  if (el.reviewMode.value === "category") {
    const checked = new Set([...el.reviewContainer.querySelectorAll(".category-check:checked")].map((x) => x.dataset.key));
    return state.suggestions.filter((item) => checked.has(categoryKey(item)));
  }
  const rows = [...el.reviewContainer.querySelectorAll(".review-item")];
  const folderMode = state.classifyingFolderTargets.length > 0;
  const out = [];
  for (const row of rows) {
    if (!row.querySelector(".bookmark-check")?.checked) continue;
    const id = row.dataset.id;
    const s = state.suggestionById.get(id);
    if (!s) continue;
    if (folderMode) {
      out.push(s);
      continue;
    }
    const main = (row.querySelector(".bookmark-main")?.value || "").trim() || "Uncertain";
    const sub = (row.querySelector(".bookmark-sub")?.value || "").trim() || "Needs-Review";
    out.push({ ...s, main, sub });
  }
  return out;
}

function refreshApplyButton() {
  el.applyBtn.disabled = confirmedFromUi().length === 0;
}

async function applyNow() {
  const list = confirmedFromUi();
  if (!list.length) {
    status("沒有已選項目可寫入。");
    return;
  }
  try {
    busy(true);
    const rootId = el.destinationRoot.value;
    const summary = state.classifyingFolderTargets.length
      ? await applyToChosenFolders(list, rootId, state.classifyingFolderTargets, state.settings.fallbackFolderName)
      : await applyWithHierarchy(list, rootId, state.settings.topFolderName);
    await storageSet({ lastApplyOperation: summary });
    await loadUndoState();
    status(`已寫入 ${summary.moved.length} 筆`);
  } catch (e) {
    status(`寫入失敗：${e.message}`);
  } finally {
    busy(false);
  }
}

async function applyToChosenFolders(items, destinationRootId, targets, fallbackName) {
  const targetIds = new Set(targets.map((t) => t.id));
  const createdFolders = [];
  const moved = [];
  let fallbackId = null;
  const cache = new Map();

  for (const item of items) {
    const original = state.bookmarkById.get(item.id);
    if (!original) continue;
    let targetId = item.resolvedFolderId || null;
    if (!targetId) {
      const byName = pickTarget(item.main, item.sub, targets);
      targetId = byName?.id || null;
    }
    if (!targetId || !targetIds.has(targetId)) {
      if (!fallbackId) fallbackId = await ensureFolder(destinationRootId, fallbackName, cache, createdFolders, 1);
      targetId = fallbackId;
    }
    const movedNode = await bookmarksMove(item.id, { parentId: targetId });
    moved.push({
      id: item.id,
      oldParentId: original.parentId,
      oldIndex: original.index,
      newParentId: movedNode.parentId,
      newIndex: movedNode.index
    });
  }
  return { createdAt: new Date().toISOString(), mode: "chosen-folders", moved, createdFolders };
}

async function applyWithHierarchy(items, destinationRootId, topFolderName) {
  const createdFolders = [];
  const moved = [];
  const cache = new Map();
  const topId = await ensureFolder(destinationRootId, topFolderName, cache, createdFolders, 1);
  for (const item of items) {
    const original = state.bookmarkById.get(item.id);
    if (!original) continue;
    const mainId = await ensureFolder(topId, item.main, cache, createdFolders, 2);
    const subId = await ensureFolder(mainId, item.sub, cache, createdFolders, 3);
    const movedNode = await bookmarksMove(item.id, { parentId: subId });
    moved.push({
      id: item.id,
      oldParentId: original.parentId,
      oldIndex: original.index,
      newParentId: movedNode.parentId,
      newIndex: movedNode.index
    });
  }
  return { createdAt: new Date().toISOString(), mode: "hierarchy", moved, createdFolders };
}

async function ensureFolder(parentId, title, cache, createdFolders, depth) {
  const safe = label(title) || "Uncertain";
  const key = `${parentId}::${safe}`;
  if (cache.has(key)) return cache.get(key);
  const children = await bookmarksGetChildren(parentId);
  const exists = children.find((x) => !x.url && x.title === safe);
  if (exists) {
    cache.set(key, exists.id);
    return exists.id;
  }
  const created = await bookmarksCreate({ parentId, title: safe });
  cache.set(key, created.id);
  createdFolders.push({ id: created.id, depth });
  return created.id;
}

async function undoNow() {
  try {
    busy(true);
    const data = await storageGet("lastApplyOperation");
    const op = data.lastApplyOperation;
    if (!op) {
      status("沒有可還原紀錄。");
      return;
    }
    const byParent = new Map();
    for (const m of op.moved || []) {
      if (!byParent.has(m.oldParentId)) byParent.set(m.oldParentId, []);
      byParent.get(m.oldParentId).push(m);
    }
    for (const list of byParent.values()) {
      list.sort((a, b) => a.oldIndex - b.oldIndex);
      for (const m of list) {
        await bookmarksMove(m.id, { parentId: m.oldParentId, index: m.oldIndex });
      }
    }
    const folders = Array.isArray(op.createdFolders) ? op.createdFolders.slice() : [];
    folders.sort((a, b) => b.depth - a.depth);
    for (const f of folders) {
      try {
        const c = await bookmarksGetChildren(f.id);
        if (!c.length) await bookmarksRemove(f.id);
      } catch {
      }
    }
    await storageRemove("lastApplyOperation");
    await loadUndoState();
    status("還原完成");
  } catch (e) {
    status(`還原失敗：${e.message}`);
  } finally {
    busy(false);
  }
}

async function loadUndoState() {
  const data = await storageGet("lastApplyOperation");
  state.canUndo = Boolean(data.lastApplyOperation);
  el.undoBtn.disabled = !state.canUndo;
}

function busy(v) {
  el.scanBtn.disabled = v;
  el.classifyBtn.disabled = v;
  el.applyBtn.disabled = v || confirmedFromUi().length === 0;
  el.undoBtn.disabled = v || !state.canUndo;
}

function status(msg) {
  const t = new Date().toLocaleTimeString("zh-Hant-HK", { hour12: false });
  el.statusBox.textContent = `[${t}] ${msg}`;
}

function label(v) {
  return typeof v === "string" ? v.trim().replace(/\s+/g, " ").slice(0, 50) : "";
}

function norm(v) {
  return String(v || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function clamp01(v) {
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0.5;
}

function esc(v) {
  return String(v)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function esca(v) {
  return esc(v).replaceAll("\n", " ");
}

function parseModelJson(raw) {
  if (!raw) return null;
  const clean = raw.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "");
  try {
    return JSON.parse(clean);
  } catch {
    const s = clean.indexOf("{");
    const e = clean.lastIndexOf("}");
    if (s >= 0 && e > s) {
      try {
        return JSON.parse(clean.slice(s, e + 1));
      } catch {
        return null;
      }
    }
    return null;
  }
}

async function askOpenRouter(prompt, settings) {
  const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${settings.apiKey}`
    },
    body: JSON.stringify({
      model: settings.model,
      temperature: settings.temperature,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt }
      ]
    })
  });
  if (!r.ok) throw new Error(`OpenRouter HTTP ${r.status}`);
  const d = await r.json();
  const content = d?.choices?.[0]?.message?.content;
  return Array.isArray(content) ? content.map((x) => x.text || "").join("\n") : String(content || "");
}

async function askGemini(prompt, settings) {
  const model = encodeURIComponent(settings.model);
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(settings.apiKey)}`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: settings.temperature,
        responseMimeType: "application/json"
      }
    })
  });
  if (!r.ok) throw new Error(`Gemini HTTP ${r.status}`);
  const d = await r.json();
  const parts = d?.candidates?.[0]?.content?.parts || [];
  return parts.map((p) => p.text || "").join("\n");
}

function bookmarksGetTree() {
  return new Promise((res, rej) => {
    chrome.bookmarks.getTree((x) => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(x));
  });
}

function bookmarksGetChildren(id) {
  return new Promise((res, rej) => {
    chrome.bookmarks.getChildren(id, (x) => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(x));
  });
}

function bookmarksCreate(payload) {
  return new Promise((res, rej) => {
    chrome.bookmarks.create(payload, (x) => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(x));
  });
}

function bookmarksMove(id, destination) {
  return new Promise((res, rej) => {
    chrome.bookmarks.move(id, destination, (x) => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(x));
  });
}

function bookmarksRemove(id) {
  return new Promise((res, rej) => {
    chrome.bookmarks.remove(id, () => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res());
  });
}

function storageGet(key) {
  return new Promise((res, rej) => {
    chrome.storage.local.get([key], (x) => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(x));
  });
}

function storageSet(payload) {
  return new Promise((res, rej) => {
    chrome.storage.local.set(payload, () => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res());
  });
}

function storageRemove(key) {
  return new Promise((res, rej) => {
    chrome.storage.local.remove([key], () => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res());
  });
}

async function uiStateGet() {
  const data = await storageGet("uiState");
  return data.uiState || {};
}

async function saveUiState() {
  await storageSet({
    uiState: {
      destinationRootId: el.destinationRoot.value,
      selectedTargetFolderIds: selectedFolderIdsFromUi()
    }
  });
}
