const DEFAULT_SETTINGS = {
  provider: "openrouter",
  apiKey: "",
  model: "google/gemini-2.0-flash-001",
  granularity: "broad",
  topFolderName: "AI Auto Sorted",
  fallbackFolderName: "AI Filtered",
  batchSize: 20,
  temperature: 0.1,
  taxonomy: [
    "Server/一般",
    "Knowledge/一般",
    "Learning/一般",
    "Tools/一般",
    "News/一般"
  ]
};

const el = {
  provider: document.getElementById("provider"),
  apiKey: document.getElementById("apiKey"),
  model: document.getElementById("model"),
  granularity: document.getElementById("granularity"),
  topFolderName: document.getElementById("topFolderName"),
  fallbackFolderName: document.getElementById("fallbackFolderName"),
  batchSize: document.getElementById("batchSize"),
  temperature: document.getElementById("temperature"),
  taxonomy: document.getElementById("taxonomy"),
  fillDefaultTaxonomy: document.getElementById("fillDefaultTaxonomy"),
  saveBtn: document.getElementById("saveBtn"),
  saveState: document.getElementById("saveState")
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  const settings = await getSettings();
  fillForm(settings);
  wireEvents();
}

function wireEvents() {
  el.provider.addEventListener("change", () => {
    if (el.provider.value === "gemini" && !el.model.value.trim()) {
      el.model.value = "gemini-2.0-flash";
    }
    if (el.provider.value === "openrouter" && !el.model.value.trim()) {
      el.model.value = "google/gemini-2.0-flash-001";
    }
  });

  el.fillDefaultTaxonomy.addEventListener("click", () => {
    el.taxonomy.value = DEFAULT_SETTINGS.taxonomy.join("\n");
  });

  el.saveBtn.addEventListener("click", async () => {
    const settings = {
      provider: el.provider.value,
      apiKey: el.apiKey.value.trim(),
      model: el.model.value.trim(),
      granularity: el.granularity.value === "detailed" ? "detailed" : "broad",
      topFolderName: el.topFolderName.value.trim() || DEFAULT_SETTINGS.topFolderName,
      fallbackFolderName: el.fallbackFolderName.value.trim() || DEFAULT_SETTINGS.fallbackFolderName,
      batchSize: clampNumber(el.batchSize.value, 1, 50, DEFAULT_SETTINGS.batchSize),
      temperature: clampNumber(el.temperature.value, 0, 1, DEFAULT_SETTINGS.temperature),
      taxonomy: parseTaxonomy(el.taxonomy.value)
    };

    if (!settings.apiKey) {
      setSaveState("請輸入 API key。", true);
      return;
    }
    if (!settings.model) {
      setSaveState("請輸入模型名稱。", true);
      return;
    }

    await storageSet({ settings });
    setSaveState("已儲存。", false);
  });
}

function fillForm(settings) {
  el.provider.value = settings.provider;
  el.apiKey.value = settings.apiKey;
  el.model.value = settings.model;
  el.granularity.value = settings.granularity;
  el.topFolderName.value = settings.topFolderName;
  el.fallbackFolderName.value = settings.fallbackFolderName;
  el.batchSize.value = String(settings.batchSize);
  el.temperature.value = String(settings.temperature);
  el.taxonomy.value = settings.taxonomy.join("\n");
}

function parseTaxonomy(input) {
  return input
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function clampNumber(raw, min, max, fallback) {
  const n = Number(raw);
  if (Number.isNaN(n)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, n));
}

function setSaveState(message, isError) {
  el.saveState.textContent = message;
  el.saveState.style.color = isError ? "#b42318" : "";
}

async function getSettings() {
  const data = await storageGet("settings");
  const settings = data.settings || {};
  return {
    ...DEFAULT_SETTINGS,
    ...settings,
    granularity: settings.granularity === "detailed" ? "detailed" : DEFAULT_SETTINGS.granularity,
    taxonomy: Array.isArray(settings.taxonomy) && settings.taxonomy.length > 0 ? settings.taxonomy : DEFAULT_SETTINGS.taxonomy
  };
}

function storageGet(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get([key], (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(result);
    });
  });
}

function storageSet(payload) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(payload, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
